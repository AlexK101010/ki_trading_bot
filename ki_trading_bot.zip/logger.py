# logger.py – Trade-Logging

import pandas as pd
import os

def logge_trade(trade, pfad="bot_log.csv"):
    df = pd.DataFrame([trade])
    if os.path.exists(pfad):
        alt = pd.read_csv(pfad)
        df = pd.concat([alt, df], ignore_index=True)
    df.to_csv(pfad, index=False)

# config.py – Konfiguration allgemeiner Konstanten

COINS = ["BTC", "ETH", "SOL", "XRP", "SUI"]

# Beispiel-API-Keys (ersetzen mit echten Werten, falls nötig)
NEWS_API_KEY = "f06c6e3435824ecabb3107328164bb72"
CRYPTO_API_KEY = "A1r3tyuiop"

INITIAL_CAPITAL = 10000
MAX_HEBEL = 5
MIN_TRADE_INTERVAL = 10  # Sekunden
AGGRESSIV_IN_DER_LERNPHASE = True

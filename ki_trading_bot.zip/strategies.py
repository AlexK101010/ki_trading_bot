# strategies.py – Dummy-Strategie-Logik

def anwenden(df):
    df["fib_signal"] = df["price"].apply(lambda p: "Buy" if p % 2 == 0 else "Sell")
    df["ma200_trend"] = df["price"].apply(lambda p: "Bullish" if p > 10000 else "Bearish")
    df["news_sentiment"] = df["price"].apply(lambda p: "Neutral")
    return df

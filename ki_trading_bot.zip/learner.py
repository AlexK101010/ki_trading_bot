# learner.py – Strategie-Scoring

from collections import defaultdict

strategie_score = defaultdict(int)

def aktualisiere_score(fib, ma200, news, reward):
    key = f"{fib}|{ma200}|{news}"
    strategie_score[key] += 1 if reward > 0 else -1

def ist_gute_kombi(fib, ma200, news):
    key = f"{fib}|{ma200}|{news}"
    return strategie_score[key] >= -3

def exportiere_scores(pfad="strategie_scores.csv"):
    import pandas as pd
    df = pd.DataFrame(strategie_score.items(), columns=["Kombi", "Score"])
    df.to_csv(pfad, index=False)
